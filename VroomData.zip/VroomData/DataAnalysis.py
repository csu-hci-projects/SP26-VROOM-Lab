import os
import csv
from statistics import mean

def takeInArgument(num: str):
    """Find the folder that starts with Vroom-Participant-{num}"""
    for item in os.listdir('.'):
        if item.startswith(f"Vroom-Participant-{num}"):
            return item
    raise FileNotFoundError(f"Could not find folder for participant {num}")


def getAverages(filepath: str):
    """Calculate averages using only built-in Python (no pandas)"""
    movement_speeds_pinch = []
    id_shannons_pinch = []
    movement_speeds_controller = []
    id_shannons_controller = []
    
    try:
        with open(filepath, 'r', newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            
            row_count = 0
            for row in reader:
                row_count += 1
                if row_count == 1:
                    continue
                if row.get("Hit") != "1":
                    continue
                
                speed = row.get("MovementTime")
                shannon = row.get("ID_Shannon")
                condition = row.get("Condition")
                
                if speed:
                    try:
                        speed_val = float(speed)
                        if condition == "HandPointPinch":
                            movement_speeds_pinch.append(speed_val)
                        elif condition == "ControllerTrigger":
                            movement_speeds_controller.append(speed_val)
                    except ValueError:
                        pass
                
                if shannon:
                    try:
                        shannon_val = float(shannon)
                        if condition == "HandPointPinch":
                            id_shannons_pinch.append(shannon_val)
                        elif condition == "ControllerTrigger":
                            id_shannons_controller.append(shannon_val)
                    except ValueError:
                        pass
    except Exception as e:
        print(f"   Error reading {filepath}: {e}")
    
    avg_speed_pinch = mean(movement_speeds_pinch) if movement_speeds_pinch else "N/A (no data)"
    avg_shannon_pinch = mean(id_shannons_pinch) if id_shannons_pinch else "N/A (no data)"
    avg_speed_controller = mean(movement_speeds_controller) if movement_speeds_controller else "N/A (no data)"
    avg_shannon_controller = mean(id_shannons_controller) if id_shannons_controller else "N/A (no data)"
    
    return (avg_speed_pinch, avg_shannon_pinch, 
            avg_speed_controller, avg_shannon_controller)


def main():
    print("=== Vroom Fitts Law Data Analysis ===\n")
    
    participant_num = input("Enter a number from 1-12 for a file: ").strip()
    
    try:
        folder_path = takeInArgument(participant_num)
        print(f"\n{folder_path}")
        
        analysis_order = [
            ("whiteboard csv", "Board_Fittslaw_Outputfile.csv"),
            ("presentation screen", "Presentation_Fittslaw_Outputfile.csv"),
            ("PDF reader", "PDF_Fittslaw_Outputfile.csv")
        ]
        
        for label, filename in analysis_order:
            file_path = os.path.join(folder_path, filename)
            
            if os.path.exists(file_path):
                print(f"\n{label.upper()} with the averages:")
                (avg_speed_pinch, avg_shannon_pinch, 
                 avg_speed_controller, avg_shannon_controller) = getAverages(file_path)
                
                print(f"   HandPointPinch - Average movement speed: {avg_speed_pinch:.2f}")
                print(f"   HandPointPinch - Average ID Shannon:     {avg_shannon_pinch:.2f}")
                print(f"   ControllerTrigger - Average movement speed: {avg_speed_controller:.2f}")
                print(f"   ControllerTrigger - Average ID Shannon:     {avg_shannon_controller:.2f}")
            else:
                print(f"\n{label.upper()} CSV not found: {filename}")
    
    except Exception as e:
        print(f"\n❌ Error: {e}")
        print("Make sure you are running the script from the folder that contains all the Vroom-Participant-* folders.")

if __name__ == "__main__":
    main()